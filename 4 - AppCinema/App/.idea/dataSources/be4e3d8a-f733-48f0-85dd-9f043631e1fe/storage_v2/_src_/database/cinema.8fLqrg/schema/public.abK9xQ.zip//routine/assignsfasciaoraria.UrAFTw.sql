create function assignsfasciaoraria() returns trigger
    language plpgsql
as
$$
DECLARE
	BEGIN
		IF(NEW.OraInizio >= TIME '16:00:00' AND NEW.OraInizio < TIME '18:00:00') then 
			UPDATE PROIEZIONE
			SET OrarioProiezione = '16-18'::FASCIORARI
			WHERE IdProiezione = NEW.IdProiezione;
		ELSIF(NEW.OraInizio >= TIME '18:00:00' AND NEW.OraInizio < TIME '20:00:00') THEN
				UPDATE PROIEZIONE
				SET OrarioProiezione = '18-20'::FASCIORARI
				WHERE IdProiezione = NEW.IdProiezione;
		ELSIF(NEW.OraInizio >= TIME '20:00:00' AND NEW.OraInizio < TIME '22:00:00') THEN
				UPDATE PROIEZIONE
				SET OrarioProiezione = '20-22'::FASCIORARI
				WHERE IdProiezione = NEW.IdProiezione;
		ELSIF(NEW.OraInizio >= TIME '22:00:00' AND NEW.OraInizio < TIME '01:00:00') THEN
				UPDATE PROIEZIONE
				SET OrarioProiezione = '22-24'::FASCIORARI
				WHERE IdProiezione = NEW.IdProiezione;
		END IF;
		RETURN NEW;
	END;

$$;

alter function assignsfasciaoraria() owner to postgres;

