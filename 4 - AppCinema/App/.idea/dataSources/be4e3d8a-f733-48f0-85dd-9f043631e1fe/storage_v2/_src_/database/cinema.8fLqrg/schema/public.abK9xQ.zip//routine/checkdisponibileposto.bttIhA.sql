create function checkdisponibileposto() returns trigger
    language plpgsql
as
$$
DECLARE

	BEGIN
		UPDATE POSTO
		SET disponibileposto = false
		WHERE idposto = NEW.IdPostoFk;
		RETURN NEW;
	END;

$$;

alter function checkdisponibileposto() owner to postgres;

