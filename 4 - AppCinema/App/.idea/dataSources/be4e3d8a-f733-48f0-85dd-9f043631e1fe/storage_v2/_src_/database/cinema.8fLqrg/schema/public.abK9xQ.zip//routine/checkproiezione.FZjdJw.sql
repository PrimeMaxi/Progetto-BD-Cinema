create function checkproiezione() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
    IF( select count(*)
        FROM proiezione
        WHERE iniziodata=NEW.iniziodata and
              finedata=NEW.finedata and
              idsalafk=NEW.idsalafk and
              orarioproiezione=NEW.orarioproiezione) = 0
    THEN
        INSERT INTO proiezione(idproiezione, iniziodata, finedata, orainizio, orafine, orarioproiezione, prezzo, idfilmfk, idsalafk) VALUES
        (new.idproiezione,new.iniziodata,new.finedata,new.orainizio,new.orafine,new.orarioproiezione,new.prezzo,new.idfilmfk,new.idsalafk);
        return new;
    ELSE
        raise exception 'Sala o fascia oraria non disponibile';
    END IF;
END
$$;

alter function checkproiezione() owner to postgres;

