create function generate_posto() returns trigger
    language plpgsql
as
$$
DECLARE
	capienza_sala INTEGER;
	filx char[];
	IdSalafk INTEGER;
	coun INTEGER := 1;
	curr varchar;
BEGIN
	filx :=ARRAY['A','B','C','D','E','F','G','H','I','L','M','N','O','P'];
	select MAX(IdSala) into IdSalafk from SALA;
	select capienza into capienza_sala from sala where IdSala = (select MAX(idsala) from sala);
	FOR item in 1..capienza_sala
	LOOP
		curr := filx[coun];
		INSERT INTO POSTO(FilaX,PostoY,IdSalaFk)
		VALUES
		(curr,coun,IdSalafk);
		coun:=coun+1;
		IF coun = 15 then coun:=1;
		END IF;
	END LOOP;
	RETURN NEW;
END;
$$;

alter function generate_posto() owner to postgres;

