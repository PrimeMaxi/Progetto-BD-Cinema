create function generate_posto() returns trigger
    language plpgsql
as
$$
DECLARE
		capienza_sala INTEGER;
		filx char[];
		IdSalafk INTEGER;
		counX INTEGER := 1;
		counY INTEGER := 1;
		curr varchar;
	BEGIN
		filx :=ARRAY['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
		IdSalafk := NEW.IdSala;
		select capienza into capienza_sala from sala where IdSala = (select MAX(idsala) from sala);
		FOR itemX in 1..capienza_sala
		LOOP
			curr := filx[counX];
			INSERT INTO POSTO(FilaX,PostoY,IdSalaFk)
			VALUES
			(curr,counY,IdSalafk);
			counY:=counY+1;
			IF counY = 15 then counY:=1; counX:= counX+1;
			END IF;
		END LOOP;
		RETURN NEW;
	END;

$$;

alter function generate_posto() owner to postgres;

