create function insertpostprenotato() returns trigger
    language plpgsql
as
$$
DECLARE
	BEGIN
		INSERT INTO POSTO_PRENOTATO(IdPostoFk,IdProiezioneFk,IdBigliettoFk)
		VALUES
		(NEW.IdPostoFk,NEW.IdProiezioneFk,NEW.IdBiglietto);
		RETURN NEW;
	END;

$$;

alter function insertpostprenotato() owner to postgres;

