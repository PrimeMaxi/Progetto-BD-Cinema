create function limit_sala() returns trigger
    language plpgsql
as
$fun$
DECLARE
	limite INTEGER;
	capienza INTEGER;
BEGIN
	select NumeroSala into limite from cinema;
	select count(*) into capienza from sala;
	
	if(capienza > limite - 1) then RAISE EXCEPTION $$Non ci sono più sale disponibili$$;
		ELSE RETURN NEW;
	END IF;
END;
$fun$;

alter function limit_sala() owner to postgres;

