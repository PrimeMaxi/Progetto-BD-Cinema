create view list_affluenza(orarioproiezione, maxaffluenza) as
SELECT pr.orarioproiezione,
       sum(b.idproiezionefk) AS maxaffluenza
FROM proiezione pr
         JOIN biglietto b ON pr.idproiezione = b.idproiezionefk
GROUP BY pr.orarioproiezione
ORDER BY (sum(b.idproiezionefk)) DESC;

alter table list_affluenza
    owner to postgres;

