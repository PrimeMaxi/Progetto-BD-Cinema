create view max_affluenza(orarioproiezione, maxaffluenza) as
SELECT list_affluenza.orarioproiezione,
       list_affluenza.maxaffluenza
FROM list_affluenza
WHERE list_affluenza.maxaffluenza = ((SELECT max(list_affluenza_1.maxaffluenza) AS max
                                      FROM list_affluenza list_affluenza_1));

alter table max_affluenza
    owner to postgres;

